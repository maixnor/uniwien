/*
 * Linux signal handling example
 * Forks a child process and does not read its return code
 *
 * Compile with:
 * $ gcc zombieland.c -o zombieland
 * Monitor with: 
 * $ watch 'ps -ao ppid,pid,stat,cmd | grep -vE "(grep)|(vim)" | grep zombie'
 */

#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>		// waitpid ()
#include <sys/syscall.h>	// syscall ()

sig_atomic_t signaled = 0;

int
main (int argc, char *argv[])
{
  pid_t pid;
  int n = 0;
  if (argc < 2)
    {
      printf ("Programm takes sleep timer as argument!\n");
      return EXIT_FAILURE;
    }
  n = atoi (argv[1]);
  if (n <= 4)
    {
      printf ("Sleep timer to small!\n");
      return EXIT_FAILURE;
    }
  else
    {
      printf ("Sleep timer set to %d seconds\n", n);
    }
  struct sigaction sa;
  void kill_zombies (int signum, siginfo_t * siginfo, void *context);

  sigfillset (&sa.sa_mask);
  /*
     //for simple signal handling 
     void kill_zombies (int signum);
     sa.sa_handler = kill_zombies;
     sa.sa_flags = 0;
     //sa.sa_flags = SA_NOCLDWAIT;  //ret of childs ignored 
  */

  //to get information form tha calling process
  sa.sa_sigaction = kill_zombies;
  sa.sa_flags = SA_SIGINFO;

  sigaction (SIGCHLD, &sa, NULL);

  if ((pid = fork ()) < 0)
    {
      perror ("Fork failed!");
      exit (1);
    }

  if (pid > 0)
    {
      /* parent */
      printf ("Parent pid \t%ld\n", (long) getpid ());
      printf ("Child  pid \t%ld\n", (long) pid);
      fflush(stdout);
      sleep (n);		// this gets interrupted by the first SIGCHLD sent 
      sleep ((int) n - 3);
      printf ("Terminating parent...\n");
      fflush(stdout);
      kill (0, SIGKILL);
    }
  else
    {
      /* child */
      sleep (3);
      /* 
       * no explicit exit needed 
       * in our case all are equivalent.
       * SIGCHLD is sent in any case once
       * to the parent
       */
      //exit (0);
      //_Exit (0);
      //syscall(SYS_exit,0);  
    }
}



void
kill_zombies (int sig, siginfo_t * siginfo, void *context)
{
  pid_t kidpid;
  int status;

  printf ("SIGCHLD recieved from PID: %ld, UID: %ld\n",
	  (long) siginfo->si_pid, (long) siginfo->si_uid);
  fflush(stdout);
  if (signaled > 0)
  {
      printf ("Kill the zombies, aim for the head!\n");
      while ((kidpid = waitpid (-1, &status, WNOHANG)) > 0)
	    {
	      printf ("Child %ld terminated\n", (long) kidpid);
        fflush(stdout);
	    }
  }
  else
  {
    signaled = 1;
  }
}
